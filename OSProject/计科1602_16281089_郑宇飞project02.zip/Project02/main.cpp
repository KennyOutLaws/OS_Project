/* author:BJTU Arnold
 * function: mutithreads soduku validator
 */
//pthread_create
#include <iostream>
#include<algorithm>
#include<pthread.h>
#include<unistd.h>
using namespace std;
#define total_threads 27
typedef struct {
    int row;
    int col;
}parameters;
int soduku[9][9]={6,2,4,5,3,9,1,8,7,
                  5,1,9,7,2,8,6,3,4,
                  8,3,7,6,1,4,2,9,5,
                  1,4,3,8,6,5,7,2,9,
                  9,5,8,2,4,7,3,6,1,
                  7,6,2,3,9,1,4,5,8,
                  3,7,1,9,5,6,8,4,2,
                  4,9,6,1,8,2,5,7,3,
                  2,8,5,4,7,3,9,1,6};
int results[27]={0};
bool is_valid(int *valid_array){
        sort(valid_array,valid_array+9);
        for(int i=0;i<=8;i++) {
            if (valid_array[i] != i + 1)
                return false;
        }
        return true;
}
void*  check_col(void *params1){
    parameters* params=(parameters*) params1;
    int row=params->row;
    int col=params->col;
    int validArray[9];
    int count=0;
    for(int i=row;i<=9;i++)
    {
        validArray[count++]=soduku[i][col];
    }
    bool flag= is_valid(validArray);
    if(flag) {
        results[9+col]=1;
        pthread_exit(NULL);
    }
    else {
        results[9+col]=0;
        pthread_exit(NULL);
    }
}
void *  check_row(void *params1){
    parameters* params=(parameters*) params1;
    int row=params->row;
    int col=params->col;
    int validArray[9];
    int count=0;
    for(int i=col;i<=9;i++)
    {
        validArray[count++]=soduku[row][i];
    }
    bool flag= is_valid(validArray);
    if(flag) {
        results[18+row]=1;
        pthread_exit(NULL);
    }
    else {
        results[18+row]=0;
        pthread_exit(NULL);
    }
}

void * check_subsets(void *params){
    parameters* params1=(parameters*) params;
    int row=params1->row;
    int col=params1->col;
    int valid_array[9];
    int count=0;
    for(int i=row;i<=row+2;i++)
        for(int j=col;j<=col+2;j++)
            valid_array[count++]=soduku[i][j];
  //  return     is_valid(valid_array);
    bool flag=is_valid(valid_array);
    if(flag){
        results[row+col/3]=1;
        pthread_exit(NULL);
    }
    else
    {
        results[row+col/3]=0;
        pthread_exit(NULL);
    }
}
int main() {
    pthread_t threads[27];
    int index=0;
    for(int i=0;i<=8;i++)
        for(int j=0;j<=8;j++)
        {
            if(i%3==0&&j%3==0) {
                auto params1 = (parameters *) malloc(sizeof(parameters));
                params1->row=i;
                params1->col=j;
                pthread_create(&threads[index++], NULL, check_subsets,params1);
            }
            if(i==0)
            {
                auto params1 = (parameters *) malloc(sizeof(parameters));
                params1->row=i;
                params1->col=j;
                pthread_create(&threads[index++], NULL, check_col,params1);
            }
            if(j==0)
            {
                auto params1 = (parameters *) malloc(sizeof(parameters));
                params1->row=i;
                params1->col=j;
                pthread_create(&threads[index++], NULL, check_row,params1);
            }
        }
    sleep(0.1);//Essential part!To prevent the circumstance that the main thread has executed here but other threads haven't all finished execution.
    for(int i=0;i<=26;i++) {
        if (results[i] == 0) {
            cout<<i<< "    "<<results[i]<<endl;
            cout << "The soduku is anomalous!" << endl;
        }
    }
    cout<<"Standard soduku!"<<endl;
    return 0;
}