#include <iostream>
#include<pthread.h>
#include<unistd.h>
using namespace std;
int list[10]={7,12,19,3,18,4,2,6,15,8};
int result1[5]={0};
int result2[5]={0};
int result[10]={0};
void *thread_sort1(void* original)
{
    int* array=(int*) original;
    sort(array,array+5);
    for(int i=0;i<=4;i++)
        result1[i]=array[i];
    pthread_exit(NULL);
}
void *thread_sort2(void* original)
{
    int* array=(int*) original;
    sort(array,array+5);
    for(int i=0;i<=4;i++)
        result2[i]=array[i];
    pthread_exit(NULL);
}
int main() {
    pthread_t  threads[2];
    pthread_create(&threads[0],NULL,thread_sort1,list);
    pthread_create(&threads[1],NULL,thread_sort2,list+5);
    sleep(1);//重要
    int count=0;
    int i=0,j=0;
    while(i<=4&&j<=4)
    {
        if(result1[i]<result2[j])
            list[count++]=result1[i++];
        else
            list[count++]=result2[j++];
    }
    while(i<=4)
        list[count++]=result1[i++];
    while(j<=4)
        list[count++]=result2[j++];
    for(int i=0;i<=9;i++)
    {
        cout<<list[i]<<" ";
    }
    return 0;
}