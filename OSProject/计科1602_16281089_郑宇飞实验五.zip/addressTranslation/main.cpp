#include <iostream>
#include<map>
using namespace std;
map<int,int> TLB;
int frame_table[256][256]={0};
int page_table[256]={0};
int frame_number=0;//Denote the current number of frame that can be allocated.
//给定一个偏移地址，
void page_fault(int page_number,int offset)
{
    //If "page fault" appeared, we could just get into the backingstore and fetch the data we want,then load them in the frame tables.
    FILE *fp2=fopen("/Users/yufeizheng/Downloads/lab05/BACKING_STORE.bin","rb");
    fseek(fp2,(page_number<<8),SEEK_SET);
    for(int i=0;i<=255;i++)//read 256 numbers into the frameTable
    {
        fread(&frame_table[frame_number][i],1,1,fp2);
        //The condition that we have read a negative number
        if(frame_table[frame_number][i]>=128)
        {
            frame_table[frame_number][i]= ~frame_table[frame_number][i];
            frame_table[frame_number][i]=frame_table[frame_number][i]&255;
            frame_table[frame_number][i]=-(frame_table[frame_number][i]+1);
        }
    }
    page_table[page_number]=frame_number;
    frame_number++;
    fclose(fp2);
}
//TLB miss the target,we gonna remedy this with the mechanism of searching in page_table
int  regular_fetch(int page_number,int offset)
{
    if(page_table[page_number]==-1)
        //page fault
    {
        page_fault(page_number,offset);
    }
    return page_table[page_number];
    //return a frame number
}
int TLB_fetch(int page_number)
{
    if(TLB.find(page_number)!=TLB.end())
        return TLB[page_number];
    else
        return -1;
}
int get_physical_address(int logical_address)
{
    //TLB method has been omitted here...
    int  page_number=logical_address>>8;
    int offset=logical_address&255;
     int k=TLB_fetch(page_number);
    if(k==-1){
    // not exsist in TLB...
    int frame = regular_fetch(page_number, offset);
       if(TLB.size()<16)
         TLB.insert(pair<int,int>(page_number,frame));
     else {
        TLB.erase(TLB.begin(),TLB.begin());
       TLB.insert(pair<int,int>(page_number,frame));
     }
    return (frame << 8) + offset;
    }
     else{
    return (k<<8)+offset;
     }
}

int getValue(int physical_address)
{
    int  frame=physical_address>>8;
    int offset=physical_address&255;
    return frame_table[frame][offset];
}

int main() {

    FILE *fp1=fopen("/Users/yufeizheng/Downloads/lab05/addresses.txt","r");
    FILE *fp3=fopen("/Users/yufeizheng/Downloads/lab05/result.txt","w");
    for(int i=0;i<=255;i++) {
        page_table[i]=-1;
    }
    if(fp1==NULL)
        cout<<"Can't open address.txt"<<endl;
    else
    {
        while(!feof(fp1))
        {
            int logical_address;
            fscanf(fp1,"%d",&logical_address);
            int physical_address=get_physical_address(logical_address);
            int value=getValue(physical_address);
            fprintf(fp3,"VIRTUAL address: %d Physical address: %d Value:%d\n",logical_address,physical_address,value);
        }
    }
}
